find.better.fit <-
function(phis,ps,x,m,g,old.fit) {
  parmat <- as.matrix(expand.grid(phis,phis,ps))
  i <- 0
  best.llik <- old.fit[5]
  best.solution <- old.fit
  if (old.fit[6]==0) {
    best.converged.llik <- old.fit[5]
    best.converged.solution <- old.fit
  } else {
    best.converged.llik <- -Inf
    best.converged.solution <- NA
  }
  repeat {
    i <- i+1
    tmp <- try(fit.zinb.2phi(x,m,g,method="Nelder-Mead",start=c(mean(x)/mean(m),parmat[i,1],parmat[i,3],parmat[i,2])))
    if (is.numeric(tmp)) {
      if (tmp[5]>best.llik) {
        best.llik <- tmp[5]
        best.solution <- tmp
      }
      if ((tmp[6]==0)&(tmp[5]>best.converged.llik)) {
        best.converged.llik <- tmp[5]
        best.converged.solution <- tmp
        if ((best.llik-tmp[5])<1e-04) {
          break
        }
      }
    }
    if (i==nrow(parmat)) break
  }
  #If a solution with convergence is found and it is not much worse than any other solution, return it.
  if (!is.na(best.converged.solution[1])&(best.llik-best.converged.llik)<1e-04) {
    return(best.converged.solution)
  } else {
    return(best.solution)
  }
}
