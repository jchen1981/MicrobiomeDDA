CSp.normfactors <-
function(counts, p=0.75) {
  samp.quantile <- apply(counts,2,function(x) quantile(x[x>0],p))
  include <- sweep(counts,2,samp.quantile,"<=")
  colSums(counts*include)
}
