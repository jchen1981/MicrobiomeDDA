mbzinb.dataset <-
function(count, sample, taxon=NULL) {
  #Return some warnings if data type is unexpected.
  #For now, I don't have anything to do with the taxonomy table so it doesn't matter.
  if (!class(count)=="matrix") {
    stop("Count table should have class matrix \n")
  }
  if (!class(sample)=="data.frame") {
    stop("Sample information should have class data.frame \n")
  }
  #Check for null names
  if (is.null(colnames(count))) {
    stop("Count matrix must have column names matching sample row names \n")
  }
  if (is.null(rownames(sample))) {
    stop("Sample data frame must have column names \n")
  }
  if (!is.null(taxon)&is.null(rownames(taxon))) {
    stop("Taxonomy table must have row names \n")
  }
  #Reorder samples to match names
  sample.match <- match(colnames(count),rownames(sample))
  if (any(is.na(sample.match))) {
    cat(paste(sum(is.na(sample.match)),"samples in count table trimmed due to missing sample information \n"))
    new.count <- count[,!is.na(sample.match)]
  } else {
#    cat("No samples trimmed \n")
    new.count <- count
  }
  new.sample <- sample[colnames(new.count),,drop=FALSE]
  #If taxonomy data supplied, reorder to match names
  if (!is.null(taxon)) {
    taxon.match <- match(rownames(count),rownames(taxon))
    if (any(is.na(taxon.match))) {
      cat(paste(sum(is.na(taxon.match)),"taxa in count table trimmed due to missing taxonomy information \n"))
      new.count <- new.count[!is.na(taxon.match),]
    } else {
#      cat("No OTU trimmed \n")
      new.count <- new.count
    }
    new.taxon <- taxon[rownames(new.count),]  
  } else {
    new.taxon <- NULL
  }
  l <- list(count=new.count, sample=new.sample, taxon=new.taxon, filtered=FALSE)
  class(l) <- "mbzinb"
  return(l)
}
