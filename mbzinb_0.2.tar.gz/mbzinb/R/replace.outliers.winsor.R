replace.outliers.winsor <-
function(mbzinb.data,upper.p=0.97) {
  m <- mbzinb.data$normFactors
  if (is.null(m)) stop("Must have normalization factors to implement outlier replacement \n")
  prop <- sweep(mbzinb.data$count,2,m,"/")
  upper.quantile <- apply(prop,1,quantile,upper.p)
  new.prop <- sweep(prop,1,upper.quantile,pmin)
  new.dat <- round(sweep(new.prop,2,m,"*"))
  #I would like to make sure that positive counts are not
  #replaced with zeros
  for (i in 1:nrow(mbzinb.data$count)) {
    to.replace <- which((mbzinb.data$count[i,]>0)&(mbzinb.data$count[i,]==0))
    new.dat[i,to.replace] <- 1
  }
  mbzinb.data$replaced.counts <- new.dat
  return(mbzinb.data)
}
