RLE.sizefactors <-
function(dat,zero.method="exclude") {
  if (zero.method=="add.one") {
    new.dat <- dat+1
  } else {
    new.dat <- dat
  }
  denoms <- exp(apply(new.dat,1,function(x) mean(log(x[!x==0]))))
  RLE.norm.counts <- sweep(new.dat,1,denoms,"/")
  if (zero.method=="add.one") {
    size.factors <- apply(RLE.norm.counts,2,median)
  }
  if (zero.method=="exclude") {
     size.factors <- apply(RLE.norm.counts,2,function(x) median(x[!x==0],na.rm=TRUE))
  }
  return(size.factors)
}
