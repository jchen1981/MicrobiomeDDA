get.zinb.est <-
function(zinb.fit) {
  if (is.list(zinb.fit)) {
    zinb.p <- exp(zinb.fit$coefficients$zero)/(1+exp(zinb.fit$coefficients$zero))
    zinb.phi <- 1/zinb.fit$theta
    zinb.pi <- exp(zinb.fit$coefficients$count)
    zinb.llik <- zinb.fit$loglik
    zinb.conv <- ifelse(zinb.fit$converged,0,1)
    return(list(pi=zinb.pi,phi=zinb.phi,p=zinb.p,loglik=zinb.llik,conv=zinb.conv))
  } else {
    return(list(pi=NA,phi=NA,p=NA,loglik=NA,conv=NA))
  }
}
