zinb.llik <-
function(pars,x,m) {
  mu <- exp(pars[1])*m
  logitp <- pars[3]
  p <- exp(logitp)/(1+exp(logitp))
  phi <- exp(-pars[2])
  zeros <- x==0
  loglik0 <- log(p + exp( log(1-p) + suppressWarnings(dnbinom(0, size = 1/phi, mu = mu[zeros], log = TRUE)) ) )
  loglik1 <- log(1-p) + suppressWarnings(dnbinom(x[!zeros], size = 1/phi, mu = mu[!zeros], log = TRUE))
  loglik <- sum(loglik0)+sum(loglik1)   
  return(-loglik)
}
