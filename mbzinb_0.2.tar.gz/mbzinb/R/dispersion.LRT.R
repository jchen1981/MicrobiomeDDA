dispersion.LRT <-
function(x,m,g,use.zeroinfl=FALSE) {
  bfit.method <- ifelse(use.zeroinfl,"zeroinfl","optim")
  #Fitting full and reduced models
  zinb.fitb <- try(fit.zinb.unconditional(x=x,m=m,method=bfit.method))
  full.fit.res <- try(fit.dispersion.unconditional(x=x,m=m,g=g,method=bfit.method))
  full.fit <- full.fit.res$fit
  #Get the estimates
  full.est <- full.fit.res$est
  estb <- get.zinb.est.if.converged(zinb.fitb)
  #Get the PValue
  lr.stat <- -2*(extract.zinb.loglik(zinb.fitb)-extract.zinb.loglik(full.fit))
  pval <- 1-pchisq(lr.stat,1)
  #Store the parameter estimates for all the models.
  coef.list <- c(full.est,estb[1:3])
  names(coef.list) <- as.character(outer(c("pi","phi","p"),c("1","2","b"), FUN=paste, sep=""))
  return(list(est=coef.list,PValue=pval,statistic=lr.stat,full.fit=full.fit,red.fit=zinb.fitb))
}
