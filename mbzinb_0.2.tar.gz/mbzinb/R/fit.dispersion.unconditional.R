fit.dispersion.unconditional <-
function(x,m,g,method="optim") {
  #Evaluate whether on boundary of parameter space
  cond1.1 <- max(x[g==1])==0
  cond1.2 <- min(x[g==1])>0
  cond1 <- cond1.1|cond1.2
  cond2.1 <- max(x[g==2])==0
  cond2.2 <- min(x[g==2])>0
  cond2 <- cond2.1|cond2.2
  #scenario with no boundary problems or when one group all nonzero and other is regular
  if ((!cond1&!cond2)|(cond2.2&!cond1)|(cond1.2&!cond2)) {
#    cat("I am in the situation in which both groups are normal or one group is normal and the other all nonzero \n")
    zinb.fit.phi <- new.phi.fit(x,m,g)
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- log(zinb.fit.phi[1])
    res$coefficients$zero <- logit(zinb.fit.phi[3])
    res$fitted.values <- zinb.fit.phi[1]*m
    res$residuals <- x-res$fitted.values
    res$theta <- c(1/zinb.fit.phi[2],1/zinb.fit.phi[4])
    res$loglik <- zinb.fit.phi[5]
    res$converged <- zinb.fit.phi[6]==0
    par.est <- list(pi1=zinb.fit.phi[1],phi1=zinb.fit.phi[2],p1=zinb.fit.phi[3],pi2=zinb.fit.phi[1],phi2=zinb.fit.phi[4],p2=zinb.fit.phi[3])
  }
  #scenario in which all nonzeros: use the negative binomial fit with common dispersion
  if (cond1.2&cond2.2) {
#    cat("I am in the situation in which there are no zeros \n")
    phi.fit <- try(optim.nbinom.2phi(x=x,m=m,g=g))
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- log(phi.fit[1])
    res$coefficients$zero <- -Inf
    res$fitted.values <- phi.fit[1]*m
    res$residuals <- x-res$fitted.values
    res$theta <- c(1/phi.fit[2],1/phi.fit[3])
    res$loglik <- phi.fit[5]
    res$converged <- phi.fit[4]==0
    par.est <- list(pi1=phi.fit[1],phi1=phi.fit[2],p1=0,pi2=phi.fit[1],phi2=phi.fit[3],p2=0)
  }
  #scenario in which all zeros
  if (cond2.1&cond1.1) {
#    cat("I am in the situation in which there are all zeros \n")
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- rep(NA,2)
    res$coefficients$zero <- c(NA,NA)
    res$fitted.values <- rep(0,length(x))
    res$residuals <- rep(0,length(x))
    res$theta <- NA    
    res$loglik <- 0
    res$converged <- TRUE
    par.est <- list(pi1=NA,phi1=NA,p1=NA,pi2=NA,phi2=NA,p2=NA)
  }
  #Scenario in which exactly Group 1 is all zero (Group 2 could be regular or
  #all nonzero)
  #Can always get Group 1 to have 0  maximized log likelihood by varying its
  #free parameters.  So find Group 2 estimates
  if (cond1.1&!cond2.1) {
#    cat("I am in the situation in which group 1 is all zero but group 2 is not \n")
    zinb.fit2 <- try(fit.zinb.unconditional(x=x[g==2],m=m[g==2],method=method))
    #There are two because I don't want the coefficients to count if it didn't
    #converge but I still want them recorded in the fit.
    est2 <- get.zinb.est(zinb.fit2)
    grp2.est <- get.zinb.est.if.converged(zinb.fit2)
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- log(est2$pi)
    res$coefficients$zero <- logit(est2$p)
    res$fitted.values <- est2$pi*m
    res$residuals <- x-res$fitted.values
    res$theta <- c(0,1/est2$phi)   
    res$loglik <- est2$loglik
    res$converged <- est2$conv==0
    par.est <- list(pi1=grp2.est$pi,phi1=Inf,p1=grp2.est$p,pi2=grp2.est$pi,phi2=grp2.est$phi,p2=grp2.est$p)
  }
  #Scenario in which exactly Group 2 is all zero (Group 1 could be regular or
  #all nonzero)
  #Can always get Group 2 to have 0  maximized log likelihood by varying its
  #free parameters.  So find Group 1 estimates
  if (cond2.1&!cond1.1) {
#    cat("I am in the situation in which group 2 is all zero but group 1 is not \n")
    zinb.fit1 <- try(fit.zinb.unconditional(x=x[g==1],m=m[g==1],method=method))
    grp1.est <- get.zinb.est.if.converged(zinb.fit1)
    est1 <- get.zinb.est(zinb.fit1)
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- log(est1$pi)
    res$coefficients$zero <- logit(est1$p)
    res$fitted.values <- est1$pi*m
    res$residuals <- x-res$fitted.values
    res$theta <- c(1/est1$phi,0)   
    res$loglik <- est1$loglik
    res$converged <- est1$conv==0
    par.est <- list(pi1=grp1.est$pi,phi1=grp1.est$phi,p1=grp1.est$p,pi2=grp1.est$pi,phi2=Inf,p2=grp1.est$p)
  } 
  return(list(fit=res,est=par.est))
}
