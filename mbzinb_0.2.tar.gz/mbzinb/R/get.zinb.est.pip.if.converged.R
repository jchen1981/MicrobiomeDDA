get.zinb.est.pip.if.converged <-
function(zinb.fit,grp2.pars=NULL) {
  if (is.list(zinb.fit)) {
    zinb.p1 <- inv.logit(zinb.fit$coefficients$zero[1])
    zinb.phi <- 1/zinb.fit$theta
    zinb.pi1 <- exp(zinb.fit$coefficients$count[1])
    zinb.conv <- ifelse(zinb.fit$converged,0,1)
    zinb.llik <- zinb.fit$loglik
    #If Group 2 parameters directly available, get these.  Otherwise
    #get the Group 2 parameter estimates from the fit.
    if (!is.null(grp2.pars)) {
      zinb.pi2 <- grp2.pars[1]
    } else {
      zinb.pi2 <- exp(zinb.fit$coefficients$count[1]+zinb.fit$coefficients$count[2])
    }
    if (!is.null(grp2.pars)) {
      zinb.p2 <- grp2.pars[3]
    } else {
      zinb.p2 <-inv.logit(zinb.fit$coefficients$zero[1]+zinb.fit$coefficients$zero[2])
    }
    if (zinb.fit$converged) {
      return(c(zinb.pi1,zinb.phi,zinb.p1,zinb.pi2,zinb.p2,zinb.llik,zinb.conv))
    } else {
      return(rep(NA,7))
    }
  } else {
    return(rep(NA,7))
  }
}
