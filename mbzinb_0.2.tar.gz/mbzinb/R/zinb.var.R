zinb.var <-
function(pars,m) {
  mu <- pars$pi*m
  p <- pars$p
  phi <- pars$phi
  p*(1-p)*mu^2+(1-p)*mu+(1-p)*mu^2*phi
}
