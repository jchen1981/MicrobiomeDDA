best.zinb.optim <- function(phis,ps,x,m,optim.method) {
  parmat <- as.matrix(expand.grid(phis,ps))
  res <- matrix(data=NA,nrow=nrow(parmat),ncol=5)
  for (i in 1:nrow(parmat)) {
    start.pi <- mean(x/m)/(1-parmat[i,2])
    tmp <- try(fit.zinb(x,m,method=optim.method,start=c(start.pi,parmat[i,1],parmat[i,2])))
    if (is.numeric(tmp)) res[i,] <- tmp    
  }
  return(res[which.max(res[,4]),])  
}

