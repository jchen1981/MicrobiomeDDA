optim.nbinom.2phi <-
function(x,m,g,start=NULL) {
  if (is.null(start)) {
    start.pi <- mean(x)/mean(m)
    obj01 <- function(y) {
      nb.llik(par=c(log(start.pi),y),x=x[g==1],m=m[g==1])
    }
    o.start1 <- optimize(f=obj01,lower=-7,upper=7)
    start.phi1 <- exp(o.start1$minimum)
    obj02 <- function(y) {
      nb.llik(par=c(log(start.pi),y),x=x[g==2],m=m[g==2])
    }
    o.start2 <- optimize(f=obj02,lower=-7,upper=7)
    start.phi2 <- exp(o.start2$minimum)
  } else {
    start.pi <- start[1]
    start.phi1 <- start[2]
    start.phi2 <- start[3]
  }
  obj <- function(pars) {
     nb.llik(par=pars[1:2],x=x[g==1],m=m[g==1])+ nb.llik(par=pars[c(1,3)],x=x[g==2],m=m[g==2])
  }
  o <- optim(par=log(c(start.pi,start.phi1,start.phi2)),fn=obj)
  return(c(pi1=exp(o$par[1]),phi1=exp(o$par[2]),phi2=exp(o$par[3]),conv=o$convergence,llik=-o$value))
}
