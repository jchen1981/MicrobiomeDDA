extract.zinb.loglik <-
function(obj) {
  if (is.list(obj)) {
    if (obj$conv) {
      return(obj$loglik)
    } else {
      return(NA)
    }
  } else {
    return(NA)
  }
}
