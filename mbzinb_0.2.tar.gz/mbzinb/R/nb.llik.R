nb.llik <-
function(par,x,m) {
   phi <-  exp(par[2])
   mu <- exp(par[1])*m
   -sum(dnbinom(x=x,mu=mu,size=1/phi,log=TRUE))
}
