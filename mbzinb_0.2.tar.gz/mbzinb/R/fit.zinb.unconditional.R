fit.zinb.unconditional <-
function(x,m,method="zeroinfl",optim.method="Nelder-Mead",...) {
  #Case where all x are 0
  if (all(x==0)) {
#    cat("All x are 0 \n")
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- NA
    res$coefficients$zero <- Inf
    res$fitted.values <- rep(0,length(x))
    res$residuals <- rep(0,length(x))
    res$theta <- NA    
    res$loglik <- 0
    res$converged <- TRUE
  }
  #Case where all x are nonzero
  if (min(x)>0) {
#    cat("All x are nonzero \n")
    nb.fit <- optim.nbinom(x,m)
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- log(nb.fit[1])
    res$coefficients$zero <- -Inf
    res$fitted.values <- nb.fit[1]*m
    res$residuals <- x-res$fitted.values
    res$theta <- 1/nb.fit[2]
    res$loglik <- nb.fit[4]
    names(res$loglik) <- NULL
    res$converged <- (nb.fit[3]==0)
  }
  #Otherwise
  if (min(x)==0&(max(x)>0)) {
#    cat("x is regular \n")
    if (method=="zeroinfl") {
      res <- zeroinfl(formula=x~1|1,dist="negbin",offset=log(m))
    }
    if (method=="optim") {
      optim.res <- fit.zinb(x,m,method=optim.method)
      if (optim.res[5]>0) {
        #If it failed to converge, try some different starting parameter values.
        new.optim.res <- best.zinb.optim(phis=c(0.01,0.1,0.5,1,5,10,100),ps=c(0.0001,0.001,0.01,0.05,0.1,0.5,0.9),x=x,m=m,optim.method=optim.method)
        #if the best fit over multiple starting values is not much worse than the original fit, use this result instead.
        if ((new.optim.res[4]-optim.res[4])> -0.0001) optim.res <- new.optim.res
      }
      res <- list()
      res <- list()
      res$coefficients <- list()
      res$coefficients$count <- log(optim.res[1])
      res$coefficients$zero <- logit(optim.res[3])
      res$fitted.values <- optim.res[1]*m
      res$residuals <- x-res$fitted.values
      res$theta <- 1/optim.res[2]
      res$loglik <- optim.res[4]
      names(res$loglik) <- NULL
      res$converged <- (optim.res[5]==0)
    }
  }
  return(res)
}
