fit.zinb <-
function(x,m,start=NULL,...) {
  if (is.null(start)) {
    #zeroinfl uses a Poisson glm on the count data to estimate pi.  Here, this GLM would just have
    #an intercept so can get the MLE analytically
    start.logpi <- log(mean(x)/mean(m))
    #zeroinfl uses a glm with the indicator of whether it is a zero as a response to get the starting value.  However, here there are no covariates for the zero probability
    start.zero <- mean(x==0)
    start.logit <- log(start.zero/(1-start.zero))
    #In the spirit of zeroinfl, I will just start with phi=1
    start.logphi <- 0
    zinb.start <- c(start.logpi,start.logphi,start.logit)
  } else {
    zinb.start <- c(log(start[1]),log(1/start[2]),log(start[3]/(1-start[3])))
  }
  o <- optim(par=zinb.start,fn=zinb.llik,gr=zinb.grad,x=x,m=m,...)
  return(c(exp(o$par[1]),exp(-o$par[2]),exp(o$par[3])/(1+exp(o$par[3])),-o$value,o$convergence))
}
