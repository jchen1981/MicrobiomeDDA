replace.outliers.cooks.onegroup <-
function(mbzinb.data,cooks.cutoff=1,use.zeroinfl=FALSE) {
  m <- mbzinb.data$normFactors
  if (is.null(m)) stop("Must have normalization factors to implement outlier replacement \n")
  new.counts <- mbzinb.data$count
  cooks.mat <- matrix(data=NA,nrow=nrow(mbzinb.data$count),ncol=ncol(mbzinb.data$count))
  for (j in 1:nrow(mbzinb.data$count)) {
    cur.counts <- mbzinb.data$count[j,]
    cur.fit <- fit.zinb.unconditional(x=cur.counts,m=m,use.zeroinfl=use.zeroinfl)
    cooks <- get.cooks(zinb.fit=cur.fit,x=cur.counts,m=m)
    cooks.mat[j,] <- cooks
    if (!is.na(cooks[1])) {
#     cat("Maximum cooksD is", max(cooks), "\n")
      to.replace <-(cooks>cooks.cutoff)&(cur.counts>0)&(cur.fit$residuals>0)
      if (sum(to.replace)>0) {
#       cat("I replaced counts in OTU",j,"\n")
        props <- mbzinb.data$count[j,]/m
        new.props <- props
        new.props[to.replace] <- max(props[!to.replace])
        new.counts[j,] <- ceiling(m*new.props)
      }
    }
  }
  mbzinb.data$replaced.counts <- new.counts
  mbzinb.data$cooksD <- cooks.mat
  return(mbzinb.data)
}
