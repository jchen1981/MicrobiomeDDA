fit.mean.prev.unconditional <-
function(x,m,g,method="optim") {
  #Evaluate whether on boundary of parameter space
  cond1.1 <- max(x[g==1])==0
  cond1.2 <- min(x[g==1])>0
  cond1 <- cond1.1|cond1.2
  cond2.1 <- max(x[g==2])==0
  cond2.2 <- min(x[g==2])>0
  cond2 <- cond2.1|cond2.2
  #scenario with no boundary problems
  if (!cond1&!cond2) {
    #Fit with mean and zero probability allowed to differ between groups
    group <- as.factor(g)
    res <- try(zeroinfl(formula=x~group|group,dist="negbin",offset=log(m)))
    est <- get.zinb.est.pip.if.converged(res)
    par.est <- list(pi1=est[1],phi1=est[2],p1=est[3],pi2=est[4],phi2=est[2],p2=est[5])
#    cat("Both groups are regular \n")
  }
  #scenario in which all nonzeros: use the negative binomial fit
  if (cond1.2&cond2.2) {
#    cat("There are no zeros \n")
    #Use a two group negative binomial fit with common dispersion
    #in this case.
    nb.fit <- try(optim.nbinom(x=x,m=m,g=g))
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- c(log(nb.fit[1]),log(nb.fit[2]/nb.fit[1]))
    res$coefficients$zero <- c(-Inf,NA)
    res$fitted.values <- nb.fit[g]*m
    res$residuals <- x-res$fitted.values
    res$theta <- 1/nb.fit[3]
    res$loglik <- nb.fit[5]
    names(res$loglik) <- NULL
    res$converged <- (nb.fit[4]==0)
    est <- get.zinb.est.pip.if.converged(res)
    par.est <- list(pi1=est[1],phi1=est[2],p1=0,pi2=est[4],phi2=est[2],p2=0)
  }
  #scenario in which all zeros
  if (cond2.1&cond1.1) {
#    cat("All counts are zero \n")
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- rep(NA,2)
    res$coefficients$zero <- c(NA,NA)
    res$fitted.values <- rep(0,length(x))
    res$residuals <- rep(0,length(x))
    res$theta <- NA    
    res$loglik <- 0
    res$converged <- TRUE
    par.est <- list(pi1=NA,phi1=NA,p1=NA,pi2=NA,phi2=NA,p2=NA)
  }
  #Scenario in which exactly Group 1 is all zero (Group 2 could be regular or
  #all nonzero)
  #Can always get Group 1 to have 0  maximized log likelihood by varying its
  #free parameters.  So find Group 2 estimates
  if (cond1.1&!cond2.1) {
#    cat("Group 1 is all zero and Group 2 is not all zero \n")
    zinb.fit2 <- try(fit.zinb.unconditional(x=x[g==2],m=m[g==2],method=method))
    est2 <- get.zinb.est(zinb.fit2)
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- c(NA,NA)
    res$coefficients$zero <- c(NA,NA)
    res$fitted.values <- rep(NA,length(x))
    res$fitted.values[g==1] <- 0
    if (is.list(zinb.fit2)) {
      res$fitted.values[g==2] <- zinb.fit2$fitted.values
    }
    res$residuals <- x-res$fitted.values
    res$theta <- 1/est2$phi
    res$loglik <- est2$loglik
    res$converged <- est2$conv==0
    grp2.est <- get.zinb.est.if.converged(zinb.fit2)
    par.est <- list(pi1=NA,phi1=grp2.est$phi,p1=NA,pi2=grp2.est$pi,phi2=grp2.est$phi,p2=grp2.est$p)
  }
  #Scenario in which exactly Group 2 is all zero (Group 1 could be regular or
  #all nonzero)
  #Can always get Group 2 to have 0  maximized log likelihood by varying its
  #free parameters.  So find Group 1 estimates
  if (cond2.1&!cond1.1) {
#    cat("Group 2 is all zero and Group 1 is not all zero \n")
    zinb.fit1 <- try(fit.zinb.unconditional(x=x[g==1],m=m[g==1],method=method))
    est1 <- get.zinb.est(zinb.fit1)
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- c(log(est1$pi),NA)
    res$coefficients$zero <- c(logit(est1$p),NA)
    res$fitted.values <- rep(NA,length(x))
    res$fitted.values[g==2] <- 0
    if (is.list(zinb.fit1)) {
      res$fitted.values[g==1] <- zinb.fit1$fitted.values
    }
    res$residuals <- x-res$fitted.values
    res$theta <- 1/est1$phi
    res$loglik <- est1$loglik
    res$converged <- est1$conv==0
    grp1.est <- get.zinb.est.if.converged(zinb.fit1)
    par.est <- list(pi1=grp1.est$pi,phi1=grp1.est$phi,p1=grp1.est$p,pi2=NA,phi2=grp1.est$phi,p2=NA)
  }
  #Scenario in Group 1 is all nonzero and Group 2 is regular
  if (!cond2&cond1.2) {
#    cat("Group 2 is regular and Group 1 is all nonzero \n")
    #Using optim to find the solution
    obj <- function(pars) {
      phi <- 1/exp(pars[2])
      nb.llik(par=c(pars[1],log(phi)),x=x[g==1],m=m[g==1])+zinb.llik(pars=c(pars[4],log(1/phi),pars[3]),x=x[g==2],m=m[g==2])
    }
    start.pi1 <- mean(x[g==1])/mean(m[g==1])
    start.pi2 <- mean(x[g==2])/mean(m[g==2])
    start.phi <- 1
    start.p <- mean(x[g==2]==0)
    start.pars <- c(log(start.pi1),log(1/start.phi),logit(start.p),log(start.pi2))
    fit <- optim(par=start.pars, fn=obj)
    #Extracting results
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- c(fit$par[1],fit$par[4]-fit$par[1])
    res$coefficients$zero <- c(-Inf,NA)
    res$fitted.values <- numeric(length(x))
    res$fitted.values[g==2] <- exp(fit$par[4])*m[g==2]
    res$fitted.values[g==1] <- exp(fit$par[1])*m[g==1]
    res$residuals <- x-res$fitted.values
    res$theta <- 1/exp(fit$par[2])
    res$loglik <- -fit$value
    res$converged <- fit$convergence==0
    par.est <- list(pi1=exp(fit$par[1]),phi1=1/exp(fit$par[2]),p1=0,pi2=exp(fit$par[4]),phi2=1/exp(fit$par[2]),p2=inv.logit(fit$par[3]))
  }
  #Scenario where Group 1 is normal and group 2 has no zeros
  if (!cond1&cond2.2) {
 #   cat("Group 1 is regular and Group 2 is all nonzero \n")
    #Using optim to find the solution
    obj <- function(pars) {
      phi <- 1/exp(pars[2])
      nb.llik(par=c(pars[4],log(phi)),x=x[g==2],m=m[g==2])+zinb.llik(pars=c(pars[1],log(1/phi),pars[3]),x=x[g==1],m=m[g==1])
    }
    start.pi1 <- mean(x[g==1])/mean(m[g==1])
    start.pi2 <- mean(x[g==2])/mean(m[g==2])
    start.phi <- 1
    start.p <- mean(x[g==1]==0)
    start.pars <- c(log(start.pi1),log(1/start.phi),logit(start.p),log(start.pi2))
    fit <- optim(par=start.pars, fn=obj)
    #Extracting results
    res <- list()
    res$coefficients <- list()
    res$coefficients$count <- c(fit$par[1],fit$par[4]-fit$par[1])
    res$coefficients$zero <- c(fit$par[3],-Inf)
    res$fitted.values <- numeric(length(x))
    res$fitted.values[g==2] <- exp(fit$par[4])*m[g==2]
    res$fitted.values[g==1] <- exp(fit$par[1])*m[g==1]
    res$residuals <- x-res$fitted.values
    res$theta <- 1/exp(fit$par[2])
    res$loglik <- -fit$value
    res$converged <- fit$convergence==0
    par.est <- list(pi1=exp(fit$par[1]),phi1=1/exp(fit$par[2]),p1=inv.logit(fit$par[3]),pi2=exp(fit$par[4]),phi2=1/exp(fit$par[2]),p2=0)
  }
  return(list(fit=res,est=par.est))
}
