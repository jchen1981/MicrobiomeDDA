replace.outliers <-
function(mbzinb.data,method="winsor",upper.p=0.97,cooks.cutoff=1,use.zeroinfl=FALSE) {
  if (method=="winsor") {
    new.dat <- replace.outliers.winsor(mbzinb.data,upper.p=upper.p)
  }
  if (method=="cooks") {
     new.dat <- replace.outliers.cooks.onegroup(mbzinb.data,cooks.cutoff=cooks.cutoff,use.zeroinfl=use.zeroinfl)
  }
  if (method=="none") {
     new.dat <- mbzinb.data
  }
  return(new.dat)
}
