norm.factors <-
function(mbzinb.data,method="RLE",p=0.75,norm.factors=NULL) {
  if (!class(mbzinb.data)=="mbzinb") stop("Input should be an object of class mbzinb \n")
  if (!is.null(norm.factors)) {
    m <- norm.factors
  }
  else {
    if (method=="RLE") {
      m <- RLE.sizefactors(mbzinb.data$count,zero.method="exclude")
    }
    if (method=="RLE2") {
      m <- RLE.sizefactors(mbzinb.data$count,zero.method="add.one")
    }
    if (method=="CSSp") {
      m <- CSp.normfactors(mbzinb.data$count, p=p)
    }
  }
  mbzinb.data$normFactors <- m
  return(mbzinb.data)
}
