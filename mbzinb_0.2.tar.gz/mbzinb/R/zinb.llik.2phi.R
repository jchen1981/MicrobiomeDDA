zinb.llik.2phi <-
function(pars,x,m,g) {
  zinb.llik(pars[1:3],x[g==1],m[g==1])+zinb.llik(pars[c(1,4,3)],x[g==2],m[g==2])
}
