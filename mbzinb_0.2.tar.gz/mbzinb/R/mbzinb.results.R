mbzinb.results <-
function(mbzinb.list,sort.by.pvalue=TRUE,nreturn=20,baseline.group=NULL,p.adj.method="fdr",include.taxonomy=FALSE) {
  group <- mbzinb.list$results$test$group
  if (is.null(baseline.group)) {
    baseline.group <- levels(factor(mbzinb.list$sample[,group]))[1]
    which.baseline <- 1
  } else {
    which.baseline <- which(levels(factor(mbzinb.list$sample[,group]))==baseline.group)
  }
  if (length(which.baseline)==0) stop("Baseline group should be a level of variable ", group , " in the sample data \n")
  ntaxa <- nrow(mbzinb.list$count)
  if (which.baseline==1) {
    base.abund <- mbzinb.list$results$est$pi1
    base.prev <- 1-mbzinb.list$results$est$p1
    base.disp <- mbzinb.list$results$est$phi1
    base.mean <- base.abund*base.prev
    other.abund <-mbzinb.list$results$est$pi2
    other.prev <- 1-mbzinb.list$results$est$p2
    other.disp <- mbzinb.list$results$est$phi2
  } else {
    base.abund <- mbzinb.list$results$est$pi2
    base.prev <- 1-mbzinb.list$results$est$p2
    base.disp <- mbzinb.list$results$est$phi2
    base.mean <- base.abund*base.prev
    other.abund <-mbzinb.list$results$est$pi1
    other.prev <- 1-mbzinb.list$results$est$p1
    other.disp <- mbzinb.list$results$est$phi1
  }
  other.mean <- other.abund*other.prev  
  if (mbzinb.list$results$test$test=="omnibus") {
    results <- data.frame(base.mean=base.mean,mean.LFC=log2(other.mean/base.mean),base.abund=base.abund,abund.LFC=log2(other.abund/base.abund),base.prev=base.prev,prev.change=other.prev-base.prev,base.disp=base.disp,disp.LFC=log2(other.disp/base.disp),statistic=mbzinb.list$results$statistic,PValue=mbzinb.list$results$PValue,Padj=p.adjust(mbzinb.list$results$PValue,method=p.adj.method))
  }
  if (mbzinb.list$results$test$test=="mean.prev") {
    results <- data.frame(base.mean=base.mean,mean.LFC=log2(other.mean/base.mean),base.abund=base.abund,abund.LFC=log2(other.abund/base.abund),base.prev=base.prev,prev.change=other.prev-base.prev,disp=base.disp,statistic=mbzinb.list$results$statistic,PValue=mbzinb.list$results$PValue,Padj=p.adjust(mbzinb.list$results$PValue,method=p.adj.method))    
  }
  if (mbzinb.list$results$test$test=="dispersion") {
    results <- data.frame(mean=base.mean,abund=base.abund,prev=base.prev,base.disp=base.disp,disp.LFC=log2(other.disp/base.disp),statistic=mbzinb.list$results$statistic,PValue=mbzinb.list$results$PValue,Padj=p.adjust(mbzinb.list$results$PValue,method=p.adj.method))    
  }
  #Any non-finite values should be set to NA
  results <-  data.frame(t(apply(results,1,replace.nonfinite.NA)))
  #Reorder results by p-value and subset if desired.
  if ((nreturn<nrow(mbzinb.list$count))&!sort.by.pvalue) cat("Warning: Results returned may not be the most significant results.  To get the", nreturn, "top results set sort.by.pvalue=TRUE. \n")
  if (sort.by.pvalue) {
    results.order <- order(results$PValue)[1:nreturn]
  } else {
    results.order <- 1:nreturn  
  }
  if (include.taxonomy) {
    return(cbind(mbzinb.list$taxon[results.order,],results[results.order,]))
  } else {
    return(results[results.order,])
  }
}
