mbzinb.test <-
function(mbzinb.data,group,filter.if.unfiltered=TRUE,LRT="omnibus",outlier.option="winsor",upper.p=0.97,cooks.cutoff=1,use.zeroinfl=FALSE) {
  if (!class(mbzinb.data)=="mbzinb") stop("Input should be an object of class mbzinb \n")
  #Checking if valid options entered
  if (!LRT %in% c("omnibus","mean.prev","dispersion")) stop("Error: LRT must be", dQuote("omnibus"), "or", dQuote("mean.prev"), "or", dQuote("dispersion"))
  if (!outlier.option %in% c("cooks","winsor","none")) stop("Error: outlier.option must be", dQuote("cooks"), dQuote("winsor"), "or", dQuote("none"))
  if (length(group)>1) stop("Error: Only one grouping variable allowed \n")
  if (!length(unique(mbzinb.data$sample[!is.na(mbzinb.data$sample[,group]),group]))==2) stop("Error: Grouping variable must have exactly two levels \n")
  if (LRT=="mean.prev") {
    if (!use.zeroinfl) {
      cat("use.optim option is currently not implemented for fitting full model in mean.prev.LRT.  Using zeroinfl instead \n")
    }
  }
  if (LRT=="dispersion") {
    if (use.zeroinfl) {
      cat("Full model for dispersion LRT cannot be fit using zeroinfl.  Using optim for this model. \n")
    }
  }
  #Filter if not already filtered unless requested not to
  if (filter.if.unfiltered&!mbzinb.data$filtered) {
    mbzinb.data <- filter.dataset(mbzinb.data)
  }
  #Calculate normalization factors if not present
  if (is.null(mbzinb.data$normFactors)) {
    mbzinb.data <- norm.factors(mbzinb.data)
  }
  #Replacing outliers
  mbzinb.data <- replace.outliers(mbzinb.data=mbzinb.data,method=outlier.option,upper.p=upper.p,cooks.cutoff=cooks.cutoff,use.zeroinfl=use.zeroinfl)
  #Performing the test
  mbzinb.data <- ZINB.LRT(mbzinb.data,group=group,test=LRT,use.zeroinfl=use.zeroinfl)
  mbzinb.data$results$test <- list(test=LRT,group=group, outlier.option=outlier.option)
  return(mbzinb.data)
}
