ZINB.LRT <-
function(mbzinb.data,group,test="omnibus",use.zeroinfl=FALSE) {
  #Use the replaced count matrix if available otherwise use the original count matrix
  if (is.null(mbzinb.data$replaced.counts)) new.dat <- mbzinb.data$count
  else new.dat <- mbzinb.data$replaced.counts
  #Get the group.
  group.factor <- factor(mbzinb.data$sample[,group])
  g0 <- as.integer(group.factor)
  #I am going to omit NA observations.
  na.obs <- is.na(g0)
  if (any(na.obs)) cat("Warning:",sum(na.obs),"individuals removed from analysis due to missing group information \n")
  g <- g0[!na.obs]
  #Matrix to store coefficients.
  ntaxa <- nrow(new.dat)
  est.data.frame <- data.frame(pi1=numeric(ntaxa),phi1=numeric(ntaxa),p1=numeric(ntaxa),pi2=numeric(ntaxa),phi2=numeric(ntaxa),p2=numeric(ntaxa),pib=numeric(ntaxa),phib=numeric(ntaxa),pb=numeric(ntaxa))
  rownames(est.data.frame) <- rownames(new.dat)
  #Vector to store p-values
  pvec <- numeric(nrow(new.dat))
  names(pvec) <- rownames(new.dat)
  #vector to store test statistics
  LRT.stat.vec <- numeric(nrow(new.dat))
  names(LRT.stat.vec) <- rownames(new.dat)
  #m is the normalization factor
  m <- mbzinb.data$normFactors[!na.obs]
  for (j in 1:ntaxa) {
    if (test=="omnibus") {
      LRT.res <- omnibus.LRT(x=new.dat[j,!na.obs],m=m,g=g,use.zeroinfl=use.zeroinfl)
    }
    if (test=="mean.prev") {
      LRT.res <- mean.prev.LRT(x=new.dat[j,!na.obs],m=m,g=g,use.zeroinfl=use.zeroinfl)
    }
    if (test=="dispersion") {
      LRT.res <- dispersion.LRT(x=new.dat[j,!na.obs],m=m,g=g,use.zeroinfl=use.zeroinfl)
    }
    est.data.frame[j,] <- LRT.res$est
    pvec[j] <- LRT.res$PValue
    LRT.stat.vec[j] <- LRT.res$statistic
    mbzinb.data$red.fit[[j]] <- LRT.res$red.fit
    if (test=="omnibus") {
      mbzinb.data$full.fit[[j]] <- list(grp1=LRT.res$grp1.fit,grp2=LRT.res$grp2.fit)
      names(mbzinb.data$full.fit[[j]]) <- levels(group.factor)
    } else {
      mbzinb.data$full.fit[[j]] <- LRT.res$full.fit
    }
  }
  mbzinb.data$results$est <- est.data.frame
  mbzinb.data$results$PValue <- pvec
  mbzinb.data$results$statistic <- LRT.stat.vec
  #Record which test was performed
  return(mbzinb.data)
}
