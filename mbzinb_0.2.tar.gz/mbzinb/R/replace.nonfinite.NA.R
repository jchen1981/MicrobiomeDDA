replace.nonfinite.NA <-
function(x) {
  x[!is.finite(x)] <- NA
  return(x)
}
