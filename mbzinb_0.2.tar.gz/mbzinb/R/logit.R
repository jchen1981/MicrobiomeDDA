logit <-
function(p) {
  log(p)-log(1-p)
}
