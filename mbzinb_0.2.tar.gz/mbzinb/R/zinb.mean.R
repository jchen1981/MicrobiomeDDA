zinb.mean <-
function(pars,m) {
  mu <- pars$pi*m
  p <- pars$p
  (1-p)*mu
}
