fit.zinb.2phi <-
function(x,m,g,start=NULL,...) {
  if (is.null(start)) {
    start.logpi <- log(mean(x)/mean(m))
    start.zero <- mean(x==0)
    start.logit <- log(start.zero/(1-start.zero))
    start.logphi1 <- 0
    start.logphi2 <- 0
    zinb.start <- c(start.logpi,start.logphi1,start.logit,start.logphi2)
  } else {
    zinb.start <- c(log(start[1]),log(1/start[2]),log(start[3]/(1-start[3])),log(1/start[4]))
  }
  o <- optim(par=zinb.start,fn=zinb.llik.2phi,gr=zinb.grad.2phi,x=x,m=m,g=g,...)
  return(c(exp(o$par[1]),exp(-o$par[2]),exp(o$par[3])/(1+exp(o$par[3])),exp(-o$par[4]),-o$value,o$convergence))
}
