zinb.grad.2phi <-
function(pars,x,m,g) {
  res1 <- zinb.grad(pars[1:3],x[g==1],m[g==1])
  res2 <- zinb.grad(pars[c(1,4,3)],x[g==2],m[g==2])
  c(res1[1]+res2[1],res1[2],res1[3]+res2[3],res2[2])
}
