filter.dataset <-
function(mbzinb.data,min.prev=0.1,min.reads=100,niter=1) {
  #Check if mbzinb.data is an mbzinb object
  if (!class(mbzinb.data)=="mbzinb") stop("Input should be an object of class mbzinb \n")
  if (!is.null(mbzinb.data$results)|!(is.null(mbzinb.data$replaced.counts))) cat("Warning: function designed for use before analysis and count replacement.  Only count, sample, taxon, and normFactors are being filtered \n")
  iterno <- 0
  #Check count condition
  count.condition <- colSums(mbzinb.data$count)>=min.reads    
  repeat {
    iterno <- iterno+1
    if (!any(count.condition)) stop("No samples remain after filtering.  Could decrease min.reads \n")
    #Filter low read count individuals
    mbzinb.data$count <-  mbzinb.data$count[,count.condition,drop=FALSE]
    mbzinb.data$sample <- mbzinb.data$sample[count.condition,,drop=FALSE]
    if (!is.null(mbzinb.data$normFactors)) {
      mbzinb.data$normFactors <- mbzinb.data$normFactors[count.condition]
    }
    #Filter low prevalence OTU
    prev<- apply(mbzinb.data$count,1,function(x) mean(x>0))
    prev.condition <- prev>=min.prev
    if (!any(prev.condition)) stop("No OTU remain after filtering.  Could decrease min.prev \n")
    mbzinb.data$count <- mbzinb.data$count[prev.condition,,drop=FALSE]
    mbzinb.data$taxon <- mbzinb.data$taxon[prev.condition,,drop=FALSE]
    #Check whether count condition satisfied in new dataset
    count.condition <- colSums(mbzinb.data$count)>=min.reads
    if (all(count.condition)) {
      break
    } else {
      if (iterno>=niter) {
        cat("Warning: after", niter, "filtering iteration(s) at least one sample has less than", min.reads, "total counts \n")
        break
      }
    }
  }
#  cat("I ran for", iterno, "iterations \n")
  mbzinb.data$filtered=TRUE
  return(mbzinb.data)
}
