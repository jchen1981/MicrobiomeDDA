get.zinb.est.if.converged <-
function(zinb.fit) {
  if (is.list(zinb.fit)) {
    if (zinb.fit$converged) {
      zinb.p <- exp(zinb.fit$coefficients$zero)/(1+exp(zinb.fit$coefficients$zero))
      zinb.phi <- 1/zinb.fit$theta
      zinb.pi <- exp(zinb.fit$coefficients$count)
      zinb.llik <- zinb.fit$loglik
      return(list(pi=zinb.pi,phi=zinb.phi,p=zinb.p,loglik=zinb.llik,conv=0))
    } else {
      return(list(pi=NA,phi=NA,p=NA,loglik=NA,conv=0))
    }
  } else {
    return(list(pi=NA,phi=NA,p=NA,loglik=NA,conv=NA))
  }
}
