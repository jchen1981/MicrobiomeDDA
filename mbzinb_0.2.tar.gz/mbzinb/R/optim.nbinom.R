optim.nbinom <-
function(x,m,g=NULL) {
  if (is.null(g)) {
    start.pi <- mean(x/m)
    obj <- function(y) {
      nb.llik(par=c(log(start.pi),y),x=x,m=m)
    }
    o.start <- optimize(f=obj,lower=-7,upper=7)
    start.phi <- exp(o.start$minimum)
    o <- optim(par=log(c(start.pi,start.phi)),fn=nb.llik,x=x,m=m)
    return(c(pi=exp(o$par[1]),phi=exp(o$par[2]),conv=o$convergence,llik=-o$value))
  } else {
    start.pi1 <- mean(x[g==1]/m[g==1])
    start.pi2 <- mean(x[g==2]/m[g==2])
    obj <- function(y) {
      nb.llik.twogroup(par=c(log(start.pi1),log(start.pi2),y),x=x,m=m,g=g)
    }
    o.start <- optimize(f=obj,lower=-7,upper=7)
    start.phi <- exp(o.start$minimum)
    obj2 <- function(y) {
      nb.llik.twogroup(y,x,m,g)
    }
    o <- optim(par=log(c(start.pi1,start.pi2,start.phi)),fn=obj2)
    return(c(pi1=exp(o$par[1]),pi2=exp(o$par[2]),phi=exp(o$par[3]),conv=o$convergence,llik=-o$value))
  }  
}
