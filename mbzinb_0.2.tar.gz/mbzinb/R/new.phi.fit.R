new.phi.fit <-
function(x,m,g) {
  NM.fit <- fit.zinb.2phi(x=x,m=m,g=g,method="Nelder-Mead")
  BFGS.fit <- fit.zinb.2phi(x=x,m=m,g=g,method="BFGS")
  better.fit <- which.max(c(NM.fit[5],BFGS.fit[5]))
  if (better.fit==1&NM.fit[6]==0) {
    return(NM.fit)
  } else {
    if (better.fit==2&BFGS.fit[6]==0) {
      return(BFGS.fit)
    } else {
#      cat("Finding a better fit \n")
      new.phi.start <- c(3,0.01,0.3,10,30,100)
      new.p.start <- c(0.01,0.1,0.5)
      if (better.fit==1) best.old.fit <- NM.fit
      if (better.fit==2) best.old.fit <- BFGS.fit
      find.better.fit(new.phi.start,new.p.start,x,m,g,best.old.fit)
    }
  }
}
