omnibus.LRT <-
function(x,m,g,use.zeroinfl=FALSE,...) {
  zinb.fit.method <- ifelse(use.zeroinfl,"zeroinfl","optim")
  zinb.fit1 <- try(fit.zinb.unconditional(x=x[g==1],m=m[g==1],method=zinb.fit.method,...))
  zinb.fit2 <- try(fit.zinb.unconditional(x=x[g==2],m=m[g==2],method=zinb.fit.method,...))
  zinb.fitb <- try(fit.zinb.unconditional(x=x,m=m,method=zinb.fit.method,...))
  #Get the estimates
  est1 <- get.zinb.est.if.converged(zinb.fit1)
  est2 <- get.zinb.est.if.converged(zinb.fit2)
  estb <- get.zinb.est.if.converged(zinb.fitb)
  #Get the PValue
  llik.full <- extract.zinb.loglik(zinb.fit1)+extract.zinb.loglik(zinb.fit2)
  llik.red <- extract.zinb.loglik(zinb.fitb)
  lr.stat <- -2*(llik.red-llik.full)
  pval <- 1-pchisq(lr.stat,3)
  #Store the parameter estimates for all the models.
  coef.list <- c(est1[1:3],est2[1:3],estb[1:3])
  names(coef.list) <- as.character(outer(c("pi","phi","p"),c("1","2","b"), FUN=paste, sep=""))
  return(list(est=coef.list,PValue=pval,statistic=lr.stat,grp1.fit=zinb.fit1,grp2.fit=zinb.fit2,red.fit=zinb.fitb))
}
