get.cooks <-
function(zinb.fit,x,m) {
  zinb.est <- get.zinb.est.if.converged(zinb.fit)
  if (any(is.na(zinb.est))) {
    cooksD <- rep(NA,length(m))
  } else {
    fitted.mean <- zinb.mean(zinb.est[1:3],m)
    fitted.var <- zinb.var(zinb.est[1:3],m)
    H <- 1/length(m)
    p.resid <- (x-fitted.mean)/sqrt(fitted.var)
    p <- 1
    cooksD <- p.resid^2*H/((1-H)^2*p)
  }
  return(cooksD)
}
