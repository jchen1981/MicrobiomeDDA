nb.llik.twogroup <-
function(par,x,m,g) {
   phi <-  exp(par[3])
   mu <- numeric(length(m))
   mu[g==1] <- exp(par[1])*m[g==1]
   mu[g==2] <- exp(par[2])*m[g==2]
   t1 <- lgamma(x+1/phi)-lgamma(x+1)-lgamma(1/phi)
   t2 <- x*log(phi*mu)
   t3 <- (x+1/phi)*log(1+phi*mu)
   return(-sum(t1)-sum(t2)+sum(t3))
}
