zinb.grad <-
function(pars,x,m,parameterization="optim") {
  mu <- m*exp(pars[1])
  phi <- exp(-pars[2])
  logitp <- pars[3]
  p <- exp(logitp)/(1+exp(logitp))
  #Zero contribution
  m0 <- m[x==0]
  mu0 <- mu[x==0]
  t1 <- (1/(1+phi*mu0))^(1/phi)
  t1b <- (1/(1+phi*mu0))^(1/phi+1)  
  dt1.dpi <- -m0*t1b
  t4 <- phi*mu0-(phi*mu0+1)*log(1+phi*mu0)
  dt1.dphi <- -(t1b*t4)/phi^2
  #nonzero contribution
  mup <- mu[!x==0]
  mp <- m[!x==0]
  xp <-  x[!x==0]
  q1 <- 1+phi*mup
  dnb.dpi <- xp*mp/mup-(xp*phi+1)*mp/q1
  t2 <- -digamma(xp+1/phi)/phi^2+digamma(1/phi)/phi^2
  t3 <- -(xp+1/phi)*mup/q1+xp/phi+log(q1)/phi^2
  dnb.dphi <- t2+t3
  #derivatives in original parameterization
  dl.dp <- sum((1-t1)/(p+(1-p)*t1))-sum(!(x==0))/(1-p)
  dl.dphi <- sum(dt1.dphi*(1-p)/(p+(1-p)*t1))+sum(dnb.dphi)
  dl.dpi <- sum(dt1.dpi*(1-p)/(p+(1-p)*t1))+sum(dnb.dpi)
  #together
  if (parameterization=="optim") {
    dl.dlogitp <- dl.dp*exp(logitp)/(1+exp(logitp))^2
    dl.dlogtheta <- -exp(-pars[2])*dl.dphi
    dl.dlogpi <- exp(pars[1])*dl.dpi
    return(c(-dl.dlogpi,-dl.dlogtheta,-dl.dlogitp))
  }
  if (parameterization=="original") {
    return(c(dl.dpi,dl.dphi,dl.dp))
  }
  if (parameterization=="log-fold-change") {
    dl.dlog2phi <- log(2)*2^log2(phi)*dl.dphi
    dl.dlog2pi <- log(2)*2^log2(exp(pars[1]))*dl.dpi
    return(c(dl.dlog2pi,dl.dlog2phi,dl.dp))
  }    
}
