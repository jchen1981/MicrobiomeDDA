inv.logit <-
function(x) {
  1/(1+exp(-x))
}
